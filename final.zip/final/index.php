<?php

// Display errors in production mode
error_reporting(0);
ini_set('display_errors', 'Off');

// let's get started
require 'application/router.php';
?>
